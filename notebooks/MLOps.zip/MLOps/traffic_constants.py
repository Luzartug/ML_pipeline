
# Features to be scaled to the z-score
DENSE_FLOAT_FEATURE_KEYS = ['co', 'nh3', 'no', 'no2', 'o3', 'pm10', 'pm2_5', 'so2']


def transformed_name(key):
    return key + '_xf'
